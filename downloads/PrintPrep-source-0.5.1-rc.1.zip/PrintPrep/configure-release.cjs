const fs=require('fs'),path=require('path');
const base=__dirname,args=process.argv.slice(2);
const read=file=>JSON.parse(fs.readFileSync(path.join(base,file),'utf8'));
const manifest=read('manifest.json'),config=read('publish-config.json');
function option(name){const i=args.indexOf(name);return i<0?null:args[i+1];}
const id=option('--plugin-id'),source=option('--source-url'),paypal=option('--paypal-url');
if(id!==null){if(!/^\d{10,30}$/.test(id))throw Error('Use the real numeric plugin ID assigned by Figma.');manifest.id=id;}
if(source!==null){const url=new URL(source);if(url.protocol!=='https:')throw Error('Source archive URL must use HTTPS.');config.sourceUrl=url.href;}
if(paypal!==null){const url=new URL(paypal);if(url.protocol!=='https:'||!['paypal.me','paypal.com','www.paypal.com'].includes(url.hostname)||url.username||url.password)throw Error('Use a direct HTTPS PayPal.Me or PayPal donation URL.');config.paypalUrl=url.href;}
if(args.includes('--no-donations'))config.paypalUrl='';
if(args.includes('--desktop-tested'))config.desktopSmokeTestPassed=true;
if(args.includes('--reset-desktop-test'))config.desktopSmokeTestPassed=false;
fs.writeFileSync(path.join(base,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync(path.join(base,'publish-config.json'),JSON.stringify(config,null,2)+'\n');
require('./build.cjs');
console.log('Release settings saved. Run npm run release:check.');

const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=__dirname,read=p=>fs.readFileSync(path.join(base,p));
const manifest=JSON.parse(read('manifest.json')),config=JSON.parse(read('publish-config.json'));
const errors=[];
const uploadBytes=['manifest.json','code.js','ui.html'].reduce((n,file)=>n+fs.statSync(path.join(base,file)).size,0);
if(uploadBytes>=14600000)errors.push('Сборка слишком велика для лимита Figma 15 МБ: '+uploadBytes+' байт.');
if(!/^\d{10,30}$/.test(manifest.id))errors.push('Нужно заменить локальный ID на настоящий ID, выданный Figma.');
if(!config.sourceUrl||!config.sourceUrl.startsWith('https://'))errors.push('Нужно указать публичную HTTPS-ссылку на архив исходников (AGPL).');
if(!config.desktopSmokeTestPassed)errors.push('Нужно завершить проверку в настольной Figma по сценарию DESKTOP-TEST.txt.');
if(config.paypalUrl){try{const u=new URL(config.paypalUrl);if(u.protocol!=='https:'||!['paypal.me','paypal.com','www.paypal.com'].includes(u.hostname)||u.username||u.password)errors.push('Ссылка поддержки должна вести напрямую на HTTPS PayPal.');}catch(_){errors.push('Некорректная ссылка PayPal.');}}
for(const p of ['main','ui'])if(!fs.existsSync(path.join(base,manifest[p])))errors.push('Нет файла '+manifest[p]);
if(JSON.stringify(manifest.networkAccess)!==JSON.stringify({allowedDomains:['none']}))errors.push('Проверьте изменённые сетевые разрешения.');
const gm=JSON.parse(read('vendor/ghostscript/manifest.json'));
for(const file of ['gs-core.js','gs-core.wasm']){
  const actual=crypto.createHash('sha256').update(read('vendor/ghostscript/'+file)).digest('hex');
  if(actual!==gm.files[file].sha256)errors.push('Изменился файл Ghostscript: '+file);
}
const ui=read('ui.html').toString();
for(const marker of ['/*__UI__*/','/*__CORE__*/','/*__EPS_WORKER__*/','/*__EPS_WASM__*/','/*__EPS_WASM_INFO__*/','/*__PUBLISH_CONFIG__*/','/*__CMYK_ICC__*/','/*__SRGB_ICC__*/'])if(ui.includes(marker))errors.push('Сборка содержит незаменённый маркер '+marker);
if(!ui.includes(config.supportEmail))errors.push('Контакт поддержки отсутствует в интерфейсе.');
if(errors.length){console.log('Комплект подготовлен. До отправки в Community осталось:\n'+errors.map(e=>'• '+e).join('\n'));process.exitCode=1;}
else console.log('Проверки публикационной сборки пройдены. Можно открыть форму публикации Figma.');

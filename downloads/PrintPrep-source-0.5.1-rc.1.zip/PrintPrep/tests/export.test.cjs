const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const C=require('../src/core.js'),PDF=require('../vendor/pdf-lib/pdf-lib.min.js');
const Pack=require('../src/asset-pack.js'),Brotli=require('../vendor/brotli/js.cjs');
const base=path.join(__dirname,'..'),s={width:90,height:50,bleed:3,safe:3,dpi:300};
const createGs=new Function('require','__dirname',fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.js'),'utf8')+';return createGhostscriptCore;')(require,path.join(base,'vendor/ghostscript'));
const near=(a,b)=>assert(Math.abs(a-b)<1e-7,`${a} != ${b}`);
test('packed asset codec handles all byte values without HTML-sensitive characters',()=>{
  for(const n of [0,1,2,3,13,127,256,65539]){
    const input=Uint8Array.from({length:n},(_,i)=>(i*17+Math.floor(i/7))&255),text=Pack.encode91(input);
    assert(!/["'\\<]/.test(text));assert.deepEqual(Pack.decode91(text),input);
  }
});
test('embedded compressed runtime restores the exact original WASM',()=>{
  const raw=fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.wasm'));
  const compressed=fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.wasm.br'));
  const restored=Brotli.decompress(Pack.decode91(Pack.encode91(compressed)));
  assert.deepEqual(Buffer.from(restored),raw);
});
test('actual Figma upload files remain below the 15 MB limit',()=>{
  const files=['manifest.json','code.js','ui.html'];
  const bytes=files.reduce((n,file)=>n+fs.statSync(path.join(base,file)).size,0);
  assert(bytes<14600000,`Upload payload ${bytes} exceeds safety budget`);
  const report=JSON.parse(fs.readFileSync(path.join(base,'build-size.json'),'utf8'));
  assert.equal(report.uploadBytes,bytes);assert.equal(report.networkDownloads,false);
});
async function sample(){const d=await PDF.PDFDocument.create(),p=d.addPage([96*C.PT,56*C.PT]);p.drawRectangle({x:0,y:0,width:p.getWidth(),height:p.getHeight(),color:PDF.rgb(.1,.3,.2)});p.drawText('VECTOR',{x:25,y:65,size:24});return d.save();}
test('millimetres, pixel rounding and validation',()=>{
  assert.equal(C.dimensions(s).pxWidth,1134);assert.equal(C.dimensions({...s,dpi:600}).pxHeight,1323);
  assert.throws(()=>C.settings({...s,width:NaN}));assert.throws(()=>C.settings({...s,safe:25}));
  assert.throws(()=>C.settings({...s,dpi:35}));assert.throws(()=>C.rasterLimit({pxWidth:20000,pxHeight:2}));
});
test('English interface and optional PayPal support without network permissions',()=>{
  for(const file of ['core.js','code.js','ui.js','ui.html','eps-worker.js'])assert(!/[\u0400-\u04ff]/.test(fs.readFileSync(path.join(base,'src',file),'utf8')),file+' contains untranslated text');
  const config=JSON.parse(fs.readFileSync(path.join(base,'publish-config.json'),'utf8'));
  assert.equal(config.paypalUrl,'https://paypal.me/edireifman');
  const html=fs.readFileSync(path.join(base,'ui.html'),'utf8');
  assert(html.includes('All features stay free.'));assert(html.includes('Support PrintPrep via PayPal'));
  const manifest=JSON.parse(fs.readFileSync(path.join(base,'manifest.json'),'utf8'));
  assert.deepEqual(manifest.networkAccess,{allowedDomains:['none']});
});
test('vector PDF: exact page, trim and bleed boxes, with/without marks',async()=>{
  const src=await sample();
  for(const bleed of [false,true])for(const marks of [false,true]){
    const doc=await PDF.PDFDocument.load(await C.makePdf(PDF,src,'vector',s,bleed,marks)),p=doc.getPage(0),m=marks?7:0;
    near(p.getWidth()/C.PT,90+(bleed?6:0)+2*m);near(p.getHeight()/C.PT,50+(bleed?6:0)+2*m);
    near(p.getTrimBox().width/C.PT,90);near(p.getTrimBox().height/C.PT,50);
    near(p.getBleedBox().width/C.PT,bleed?96:90);
    const imgs=doc.context.enumerateIndirectObjects().filter(([,o])=>o.dict&&o.dict.get(PDF.PDFName.of('Subtype'))===PDF.PDFName.of('Image'));
    assert.equal(imgs.length,0);
  }
});
const icc=fs.readFileSync(path.join(base,'vendor/icc/default_cmyk.icc'));
const rgb=fs.readFileSync(path.join(base,'vendor/icc/srgb.icc'));
test('ICC upload validation rejects RGB, malformed and device-link profiles',()=>{
  assert.equal(C.validateCmykProfile(icc).space,'CMYK');
  assert.throws(()=>C.validateCmykProfile(rgb),/CMYK output/);
  assert.throws(()=>C.validateCmykProfile(new Uint8Array(128)));
  const broken=new Uint8Array(icc);broken.set([108,105,110,107],12);assert.throws(()=>C.validateCmykProfile(broken),/device-link/);
});
async function colourConvert(format,src,dpi=300){
  const gs=await createGs({wasmBinary:fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.wasm')),print(){},printErr(){}});
  gs.FS.writeFile('/input.pdf',src);gs.FS.writeFile('/target.icc',icc);gs.FS.writeFile('/source.icc',rgb);
  const d=C.dimensions({...s,dpi});assert.equal(gs.callMain(C.cmykArgs(format,dpi,d.pxWidth,d.pxHeight,1)),0);return gs.FS.readFile('/output');
}
function noRgb(pdf){
  let cmyk=0;
  for(const [,obj] of pdf.context.enumerateIndirectObjects()){
    if(obj.dict&&obj.dict.get(PDF.PDFName.of('Subtype'))===PDF.PDFName.of('Image')){
      const cs=String(obj.dict.get(PDF.PDFName.of('ColorSpace')));assert(!cs.includes('DeviceRGB'));
    }
    if(obj.dict&&obj.dict.get(PDF.PDFName.of('Filter'))){
      let text;try{text=Buffer.from(PDF.decodePDFRawStream(obj).decode()).toString('latin1');}catch(_){continue;}
      assert(!/(?:^|\s)(?:rg|RG)(?:\s|$)/.test(text),'Found an RGB painting operator');
      if(/(?:^|\s)(?:k|K)(?:\s|$)/.test(text))cmyk++;
    }
  }
  assert(cmyk>0,'Expected CMYK painting operators');
}
test('CMYK PDF uses ICC conversion, preserves vectors and exact trim boxes',async()=>{
  const out=await colourConvert('pdf-vector',await sample());
  const finished=await C.finalizeCmykPdf(PDF,out,s,true,false,icc,'SWOP test'),doc=await PDF.PDFDocument.load(finished);
  noRgb(doc);near(doc.getPage(0).getTrimBox().width/C.PT,90);near(doc.getPage(0).getTrimBox().height/C.PT,50);
  const intents=doc.catalog.lookup(PDF.PDFName.of('OutputIntents'),PDF.PDFArray),intent=doc.context.lookup(intents.get(0)),profile=doc.context.lookup(intent.get(PDF.PDFName.of('DestOutputProfile')));
  assert.equal(profile.dict.get(PDF.PDFName.of('N')).asNumber(),4);
  assert.deepEqual(Buffer.from(PDF.decodePDFRawStream(profile).decode()),Buffer.from(icc));
  assert.equal(doc.context.enumerateIndirectObjects().filter(([,o])=>o.dict&&o.dict.get(PDF.PDFName.of('Subtype'))===PDF.PDFName.of('Image')).length,0);
});
test('CMYK TIFF contains four channels, correct pixels/DPI and the selected ICC',async()=>{
  const src=await sample();
  for(const dpi of [72,300,450,600]){
    const d=C.dimensions({...s,dpi}),bytes=C.finalizeCmykTiff(await colourConvert('tiff',src,dpi),icc,dpi,d.pxWidth,d.pxHeight);
    const v=new DataView(bytes.buffer,bytes.byteOffset),little=bytes[0]===73,o=v.getUint32(4,little),count=v.getUint16(o,little),tags=new Map();
    for(let i=0;i<count;i++){const p=o+2+i*12;tags.set(v.getUint16(p,little),p);}
    const scalar=t=>{const p=tags.get(t);return v.getUint16(p+2,little)===3?v.getUint16(p+8,little):v.getUint32(p+8,little);};
    assert.equal(scalar(256),d.pxWidth);assert.equal(scalar(257),d.pxHeight);assert.equal(scalar(262),5);assert.equal(scalar(277),4);assert.equal(scalar(332),1);
    const xr=scalar(282);assert.equal(v.getUint32(xr,little)/v.getUint32(xr+4,little),dpi);
    const at=scalar(34675);assert.deepEqual(Buffer.from(bytes.subarray(at,at+icc.length)),Buffer.from(icc));
  }
});
test('CMYK EPS remains vector when re-opened without a colour conversion',async()=>{
  const eps=C.epsBounds(await colourConvert('eps',await sample()),s,true,false);
  assert.match(Buffer.from(eps).toString('latin1'),/^%!PS-Adobe-3.0 EPSF-3.0/);
  const gs=await createGs({wasmBinary:fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.wasm')),print(){},printErr(){}});
  gs.FS.writeFile('/input.eps',eps);assert.equal(gs.callMain(['-dSAFER','-dBATCH','-dNOPAUSE','-dQUIET','-dEPSCrop','-sDEVICE=pdfwrite','-sColorConversionStrategy=LeaveColorUnchanged','-sOutputFile=/out.pdf','/input.eps']),0);
  noRgb(await PDF.PDFDocument.load(gs.FS.readFile('/out.pdf')));
});
test('RGB images and transparency groups are converted to CMYK',async()=>{
  const zlib=require('node:zlib');
  function chunk(type,data){const name=Buffer.from(type),n=Buffer.alloc(4);n.writeUInt32BE(data.length);const crc=Buffer.alloc(4);crc.writeUInt32BE(C.crc32(Buffer.concat([name,data])));return Buffer.concat([n,name,data,crc]);}
  const ih=Buffer.alloc(13);ih.writeUInt32BE(64,0);ih.writeUInt32BE(64,4);ih[8]=8;ih[9]=2;
  const scan=Buffer.alloc(64*(1+64*3));for(let y=0;y<64;y++)for(let x=0;x<64;x++)scan.set([(x*17+y*13)&255,(x*23+y*29)&255,(x*31+y*11)&255],y*193+1+x*3);
  const png=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(scan)),chunk('IEND',Buffer.alloc(0))]);
  const src=await PDF.PDFDocument.create(),p=src.addPage([96*C.PT,56*C.PT]),image=await src.embedPng(png);
  p.drawImage(image,{x:0,y:0,width:80,height:80});p.drawRectangle({x:50,y:20,width:60,height:50,color:PDF.rgb(.8,.2,.4),opacity:.5});
  const out=await colourConvert('pdf-vector',await src.save()),pdf=await PDF.PDFDocument.load(out);
  const objects=pdf.context.enumerateIndirectObjects().map(([,obj])=>obj);
  const images=objects.filter(obj=>obj.dict&&obj.dict.get(PDF.PDFName.of('Subtype'))===PDF.PDFName.of('Image'));
  function space(value){
    const cs=pdf.context.lookup(value);if(!cs)return '';
    if(cs instanceof PDF.PDFName)return cs.asString();
    if(cs instanceof PDF.PDFArray){const kind=String(cs.get(0));if(kind==='/Indexed')return space(cs.get(1));if(kind==='/ICCBased'){const stream=pdf.context.lookup(cs.get(1));return 'ICC'+stream.dict.get(PDF.PDFName.of('N')).asNumber();}return String(cs);}
    return String(cs);
  }
  const imageSpaces=images.map(obj=>space(obj.dict.get(PDF.PDFName.of('ColorSpace'))));
  assert(imageSpaces.some(cs=>cs==='/DeviceCMYK'||cs==='ICC4'),JSON.stringify(imageSpaces));
  for(const obj of objects)if(obj.dict){const cs=space(obj.dict.get(PDF.PDFName.of('ColorSpace'))||obj.dict.get(PDF.PDFName.of('CS')));assert(!cs.includes('DeviceRGB')&&cs!=='ICC3','RGB resource remained: '+cs);}
});
test('host: invalid selection, resized frame, PDF/EPS/TIFF routing, cleanup',async()=>{
  let out=[],formats=[],removed=0,links=[];
  const f={type:'FRAME',name:'Card',width:96*C.PT,height:56*C.PT,visible:true,absoluteTransform:[[1,0,0],[0,1,0]],children:[],getPluginData:()=>JSON.stringify(s),clone(){return {removed:false};}};
  const figma={showUI(){},on(){},openExternal(url){links.push(url);},currentPage:{selection:[]},ui:{postMessage:m=>out.push(m)},createFrame(){return {resize(){},appendChild(c){this.child=c;},async exportAsync(o){formats.push(o);return new Uint8Array([1]);},remove(){this.removed=true;this.child.removed=true;removed++;}};}};
  vm.runInNewContext(fs.readFileSync(path.join(base,'code.js'),'utf8'),{figma,__html__:'',Uint8Array});
  await figma.ui.onmessage({type:'support-paypal',url:'https://not-the-configured-link.invalid'});
  assert.deepEqual(links,['https://paypal.me/edireifman']);
  await figma.ui.onmessage({type:'export',dpi:300,format:'pdf-vector'});assert(out.some(m=>m.type==='error'));
  figma.currentPage.selection=[f];out=[];
  for(const format of ['pdf-vector','eps','tiff'])await figma.ui.onmessage({type:'export',dpi:600,format,withBleed:true,marks:true});
  assert.deepEqual(formats.map(x=>x.format),['PDF','PDF','PDF']);assert.equal(removed,3);
  f.width++;out=[];await figma.ui.onmessage({type:'export',dpi:300,format:'pdf-vector'});assert(out.some(m=>m.type==='error'&&m.message.includes('frame size')));
});

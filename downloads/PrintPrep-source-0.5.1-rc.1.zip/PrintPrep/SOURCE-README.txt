PrintPrep 0.5.1-rc.1 — source distribution

All editable plugin source is in src/. Vendor runtimes, notices and immutable
source references are included in vendor/ and ИСХОДНИКИ-И-ЛИЦЕНЗИИ.txt.
Generated code.js and ui.html are deliberately omitted from this source archive.

Build offline with Node.js 20 or later:
  node build.cjs
Run tests:
  npm test
Review publication readiness:
  npm run release:check

The manifest carries the Figma plugin ID 1703846223061012575. Before Community
submission, use configure-release.cjs to bind the public matching source-archive
URL, then complete the desktop test documented in
community/DESKTOP-TEST.txt. Do not mark that test passed before running it.
Read community/PUBLISHING.txt for the full preparation and submission steps.

English interface. All features free. Optional tips: https://paypal.me/edireifman
Support: edireifman@gmail.com. Licence: GNU AGPLv3, see LICENSE.

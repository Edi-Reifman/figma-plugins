// Optional rebuild. The delivered code.js and ui.html are ready to import.
const fs = require('fs');
const path = require('path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const pack = require('./src/asset-pack.js');
const base = __dirname;
let lib;
const bundled = path.join(base,'vendor/pdf-lib/pdf-lib.min.js');
if (fs.existsSync(bundled)) lib = bundled;
else {
try { lib = require.resolve('pdf-lib/dist/pdf-lib.min.js'); }
catch (_) {
  const runtime = process.env.PRINTPREP_NODE_MODULES;
  if (!runtime) throw new Error('Run npm install first, or set PRINTPREP_NODE_MODULES to a directory containing pdf-lib.');
  lib = path.join(runtime, 'pdf-lib/dist/pdf-lib.min.js');
}
}
const read = p => fs.readFileSync(path.join(base,p),'utf8');
const publishConfig=JSON.parse(read('publish-config.json'));
fs.writeFileSync(path.join(base,'code.js'),read('src/core.js')+'\nconst RELEASE_LINKS='+JSON.stringify(publishConfig)+';\n'+read('src/code.js'));
let html = read('src/ui.html');
for (const [key,contents] of [['PDF_LIB',fs.readFileSync(lib,'utf8')],['CORE',read('src/core.js')],['UI',read('src/ui.js')]]) {
  html = html.replace('/*__'+key+'__*/',()=>contents.replace(/<\/script/gi,'<\\/script'));
}
const decoder='(function(){const module={exports:{}};(function(module,exports){\n'+read('vendor/brotli/js.cjs')+'\n})(module,module.exports);self.PrintBrotli=module.exports;})();';
html=html.replace('/*__EPS_WORKER__*/',()=>JSON.stringify(read('src/asset-pack.js')+'\n'+read('src/core.js')+'\n'+decoder+'\n'+read('vendor/ghostscript/gs-core.js')+'\n'+read('src/eps-worker.js')).replace(/<\/script/gi,'<\\/script'));
const rawWasm=fs.readFileSync(path.join(base,'vendor/ghostscript/gs-core.wasm'));
const compressedPath=path.join(base,'vendor/ghostscript/gs-core.wasm.br');
let compressed=fs.existsSync(compressedPath)?fs.readFileSync(compressedPath):null;
if(!compressed||!zlib.brotliDecompressSync(compressed).equals(rawWasm)){
  compressed=zlib.brotliCompressSync(rawWasm,{params:{[zlib.constants.BROTLI_PARAM_QUALITY]:11}});
  fs.writeFileSync(compressedPath,compressed);
}
html=html.replace('/*__EPS_WASM__*/',()=>JSON.stringify(pack.encode91(compressed)));
const wasmInfo={bytes:rawWasm.length,sha256:crypto.createHash('sha256').update(rawWasm).digest('hex')};
html=html.replace('/*__EPS_WASM_INFO__*/',()=>JSON.stringify(wasmInfo));
html=html.replace('/*__PUBLISH_CONFIG__*/',()=>JSON.stringify(publishConfig).replace(/</g,'\\u003c'));
html=html.replace('/*__CMYK_ICC__*/',()=>JSON.stringify(fs.readFileSync(path.join(base,'vendor/icc/default_cmyk.icc')).toString('base64')));
html=html.replace('/*__SRGB_ICC__*/',()=>JSON.stringify(fs.readFileSync(path.join(base,'vendor/icc/srgb.icc')).toString('base64')));
const uploadBytes=Buffer.byteLength(html)+fs.statSync(path.join(base,'code.js')).size+fs.statSync(path.join(base,'manifest.json')).size;
if(uploadBytes>=14600000)throw new Error('Figma upload exceeds the 14.6 MB safety budget: '+uploadBytes+' bytes.');
fs.writeFileSync(path.join(base,'ui.html'),html);
fs.writeFileSync(path.join(base,'build-size.json'),JSON.stringify({uploadBytes,limitBytes:15000000,safetyBudgetBytes:14600000,wasm:wasmInfo,compressedWasmBytes:compressed.length,encoding:'Brotli + lossless ASCII91',networkDownloads:false},null,2)+'\n');
const license=fs.existsSync(path.join(path.dirname(lib),'LICENSE.md'))?path.join(path.dirname(lib),'LICENSE.md'):path.join(path.dirname(lib),'../LICENSE.md');
fs.copyFileSync(license,path.join(base,'PDF-LIB-LICENSE.md'));
console.log('Built code.js and ui.html; Figma payload '+uploadBytes+' / 15000000 bytes.');

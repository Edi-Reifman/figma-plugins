// Lossless text transport for the locally embedded compressed runtime.
// Alphabet excludes quotes, backslash and '<', so HTML/JSON need no per-byte escaping.
(function(root){
  'use strict';
  const alphabet=Array.from({length:95},(_,i)=>String.fromCharCode(i+32)).filter(c=>!['"',"'",'\\','<'].includes(c)).join('');
  const lookup=new Int16Array(128);lookup.fill(-1);for(let i=0;i<alphabet.length;i++)lookup[alphabet.charCodeAt(i)]=i;
  function encode91(bytes){
    let buffer=0,bits=0,part='',parts=[];
    for(const byte of bytes){buffer|=byte<<bits;bits+=8;
      if(bits>13){let v=buffer&8191;if(v>88){buffer>>>=13;bits-=13;}else{v=buffer&16383;buffer>>>=14;bits-=14;}
        part+=alphabet[v%91]+alphabet[Math.floor(v/91)];if(part.length>=16384){parts.push(part);part='';}}
    }
    if(bits){part+=alphabet[buffer%91];if(bits>7||buffer>90)part+=alphabet[Math.floor(buffer/91)];}
    parts.push(part);return parts.join('');
  }
  function decode91(text){
    const result=new Uint8Array(Math.ceil(text.length*7/8));let buffer=0,bits=0,value=-1,pos=0;
    for(let i=0;i<text.length;i++){
      const code=text.charCodeAt(i),c=code<128?lookup[code]:-1;if(c<0)throw new Error('Invalid packed runtime data.');
      if(value<0)value=c;else{value+=c*91;buffer|=value<<bits;bits+=(value&8191)>88?13:14;
        do{result[pos++]=buffer&255;buffer>>>=8;bits-=8;}while(bits>7);value=-1;}
    }
    if(value>=0)result[pos++]=(buffer|value<<bits)&255;
    return result.slice(0,pos);
  }
  const api={encode91,decode91};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PrintAssetPack=api;
})(typeof globalThis!=='undefined'?globalThis:this);

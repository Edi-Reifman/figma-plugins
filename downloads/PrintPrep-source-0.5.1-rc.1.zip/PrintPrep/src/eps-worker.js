// Every output passes through ICC-managed CMYK conversion in a disposable Worker.
self.onmessage = async event => {
  const {pdf,packedWasm,wasmInfo,dpi,format,width,height,icc,rgb,intent}=event.data;
  const log=[];
  console.log=console.warn=console.error=(...args)=>{log.push(args.join(' '));if(log.length>40)log.shift();};
  try {
    const wasm=PrintBrotli.decompress(PrintAssetPack.decode91(packedWasm));
    if(wasm.length!==wasmInfo.bytes)throw new Error('Runtime size mismatch.');
    if(self.crypto&&self.crypto.subtle){
      const hash=new Uint8Array(await self.crypto.subtle.digest('SHA-256',wasm));
      const hex=Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('');
      if(hex!==wasmInfo.sha256)throw new Error('Runtime integrity check failed.');
    }
    const gs=await createGhostscriptCore({wasmBinary:wasm,print:(s)=>log.push(s),printErr:(s)=>log.push(s)});
    PrintCore.validateCmykProfile(icc);
    gs.FS.writeFile('/input.pdf',new Uint8Array(pdf));
    gs.FS.writeFile('/target.icc',new Uint8Array(icc));
    gs.FS.writeFile('/source.icc',new Uint8Array(rgb));
    const rc=gs.callMain(PrintCore.cmykArgs(format,dpi,width,height,intent));
    if(rc!==0)throw new Error('CMYK conversion failed.');
    const bytes=gs.FS.readFile('/output');
    self.postMessage({bytes},[bytes.buffer]);
  } catch(e) { self.postMessage({error:'CMYK conversion failed. Check your output ICC profile, lower the DPI or simplify complex effects.'}); }
};

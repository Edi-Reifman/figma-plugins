'use strict';
const KEY = 'printprep.v1';
figma.showUI(__html__, { width: 420, height: 730, themeColors: true });
let busy = false;
function config(node) {
  try { const raw = node.getPluginData(KEY); return raw ? PrintCore.settings(JSON.parse(raw)) : null; } catch (_) { return null; }
}
function selected() {
  const nodes = figma.currentPage.selection;
  if (nodes.length !== 1 || nodes[0].type !== 'FRAME') return null;
  return nodes[0];
}
function sendSelection() {
  const node = selected();
  figma.ui.postMessage({ type:'selection', node: node ? { id:node.id, name:node.name, width:node.width, height:node.height, config:config(node) } : null });
}
figma.on('selectionchange', sendSelection);
function guides(s) {
  const p = PrintCore.PT, b = s.bleed, w = s.width, h = s.height, a = s.safe;
  return [
    ...[b,b+w,b+a,b+w-a].map(v => ({axis:'X', offset:v*p})),
    ...[b,b+h,b+a,b+h-a].map(v => ({axis:'Y', offset:v*p}))
  ];
}
function checkSize(node, s) {
  const d = PrintCore.dimensions(s);
  if (Math.abs(node.width - d.ptWidth) > 0.02 || Math.abs(node.height - d.ptHeight) > 0.02)
    throw new Error('The frame size has changed. Restore its original size or attach matching settings before exporting. This prevents stretching your artwork.');
}
function checkTransform(node) {
  const t = node.absoluteTransform;
  if (Math.abs(t[0][0]-1)>0.0001 || Math.abs(t[0][1])>0.0001 || Math.abs(t[1][0])>0.0001 || Math.abs(t[1][1]-1)>0.0001)
    throw new Error('Use an unrotated, unflipped frame with no scaling applied by its parent.');
}
async function preflight(node, s) {
  const warnings = [], p = PrintCore.PT;
  let checked = 0, uncertain = 0, effects = 0, count = 0;
  const root = node.absoluteTransform;
  const safe = { x:root[0][2] + (s.bleed+s.safe)*p, y:root[1][2] + (s.bleed+s.safe)*p,
    r:root[0][2] + (s.bleed+s.width-s.safe)*p, b:root[1][2] + (s.bleed+s.height-s.safe)*p };
  const cache = new Map();
  async function walk(n) {
    if (n.visible === false || n.opacity === 0) return;
    if (++count > 10000) throw new Error('This layout has too many layers to check at once. Split it into smaller layouts.');
    const label = n.name.slice(0, 100);
    if (n !== node && n.type === 'TEXT' && n.absoluteBoundingBox) {
      const q = n.absoluteBoundingBox;
      if (q.x < safe.x-0.05 || q.y < safe.y-0.05 || q.x+q.width > safe.r+0.05 || q.y+q.height > safe.b+0.05)
        warnings.push({level:'warning',text:`Text “${label}” extends beyond the safe area.`});
      if (n.hasMissingFont) warnings.push({level:'warning',text:`Text “${label}” has a missing font.`});
    }
    if (n.effects && n.effects.some(e=>e.visible !== false)) effects++;
    for (const paint of (Array.isArray(n.fills) ? n.fills : [])) {
      if (paint.type !== 'IMAGE' || paint.visible === false || !paint.imageHash) continue;
      if (!cache.has(paint.imageHash)) {
        const image = figma.getImageByHash(paint.imageHash);
        cache.set(paint.imageHash, image ? await image.getSizeAsync() : null);
      }
      const size = cache.get(paint.imageHash);
      if (!size) { uncertain++; continue; }
      const t = n.absoluteTransform;
      const w = n.width * Math.hypot(t[0][0], t[1][0]);
      const h = n.height * Math.hypot(t[0][1], t[1][1]);
      let density;
      if (paint.scaleMode === 'FILL') density = 72 / Math.max(w/size.width,h/size.height);
      else if (paint.scaleMode === 'FIT') density = 72 / Math.min(w/size.width,h/size.height);
      else { uncertain++; continue; }
      if (!Number.isFinite(density) || density <= 0) { uncertain++; continue; }
      checked++;
      if (density + 0.5 < s.dpi)
        warnings.push({level:'warning',text:`Image in “${label}”: about ${Math.floor(density)} PPI, below the ${s.dpi} target. Use a larger source image.`});
    }
    if ('children' in n) for (const child of n.children) await walk(child);
  }
  await walk(node);
  if (uncertain) warnings.push({level:'warning',text:`Cropped, tiled or unavailable source images: ${uncertain}. Check their effective PPI manually.`});
  if (effects) warnings.push({level:'info',text:`Layers with effects: ${effects}. Figma controls their rasterization in vector PDF; the selected DPI does not guarantee effect resolution.`});
  warnings.push({level:'info',text:'Exports are converted from Figma sRGB to the selected CMYK ICC profile. PDF/X conformance, ink limits, overprint and spot colours are not checked.'});
  return { warnings, checked, uncertain };
}
figma.ui.onmessage = async msg => {
  if (msg.type === 'ready') { sendSelection(); return; }
  if (msg.type === 'support-paypal') { if(RELEASE_LINKS.paypalUrl)figma.openExternal(RELEASE_LINKS.paypalUrl); return; }
  if (msg.type === 'view-source') { if(RELEASE_LINKS.sourceUrl)figma.openExternal(RELEASE_LINKS.sourceUrl); return; }
  if (busy) return;
  busy = true;
  try {
    if (msg.type === 'create') {
      const s = PrintCore.settings(msg.settings), d = PrintCore.dimensions(s);
      const f = figma.createFrame();
      f.name = `${String(msg.name || 'Print layout').slice(0,100)} · ${s.width} × ${s.height} mm`;
      f.resize(d.ptWidth, d.ptHeight); f.clipsContent = true;
      f.fills = [{type:'SOLID', color:{r:1,g:1,b:1}}];
      f.x = Math.round(figma.viewport.center.x - f.width/2); f.y = Math.round(figma.viewport.center.y - f.height/2);
      f.guides = guides(s); f.setPluginData(KEY, JSON.stringify(s));
      figma.currentPage.selection = [f]; figma.viewport.scrollAndZoomIntoView([f]);
      figma.ui.postMessage({type:'created'}); sendSelection();
    } else if (msg.type === 'attach') {
      const node = selected(); if (!node) throw new Error('Select one frame.');
      const s = PrintCore.settings(msg.settings);
      checkSize(node,s); checkTransform(node);
      node.setPluginData(KEY,JSON.stringify(s)); node.guides = guides(s); sendSelection();
      figma.ui.postMessage({type:'attached'});
    } else if (msg.type === 'check' || msg.type === 'export') {
      const node = selected(); if (!node) throw new Error('Select one layout frame.');
      let s = config(node); if (!s) throw new Error('Create a layout with PrintPrep or attach its settings to an existing frame first.');
      s = PrintCore.settings({...s,dpi:msg.dpi});
      checkSize(node,s); checkTransform(node);
      const report = await preflight(node,s);
      figma.ui.postMessage({type:'report',report,forExport:msg.type==='export'});
      if (msg.type === 'check') { figma.ui.postMessage({type:'checked'}); return; }
      const format = msg.format;
      if (!['pdf-vector','eps','tiff'].includes(format)) throw new Error('Choose PDF, EPS or TIFF.');
      const withBleed = !!msg.withBleed;
      const d = PrintCore.dimensions(s,withBleed);
      if (format==='tiff') PrintCore.rasterLimit(d);
      // Work on a disposable clone so selection, guides and original art stay intact.
      let copy, wrapper;
      try {
        copy = node.clone(); copy.visible = true; copy.locked = false; copy.guides = []; copy.clipsContent = true;
        wrapper = figma.createFrame(); wrapper.name = '__PrintPrep_export__';
        wrapper.resize(d.ptWidth,d.ptHeight); wrapper.fills = []; wrapper.clipsContent = true;
        wrapper.appendChild(copy); copy.x = withBleed ? 0 : -s.bleed*PrintCore.PT; copy.y = withBleed ? 0 : -s.bleed*PrintCore.PT;
        const bytes = await wrapper.exportAsync({format:'PDF',colorProfile:'SRGB',useAbsoluteBounds:true});
        figma.ui.postMessage({type:'exported',bytes,settings:s,withBleed,marks:format!=='tiff'&&!!msg.marks,format,name:node.name});
      } finally {
        if (wrapper && !wrapper.removed) wrapper.remove();
        else if (copy && !copy.removed) copy.remove();
      }
    }
  } catch (e) { figma.ui.postMessage({type:'error',message:String(e.message || e)}); }
  finally { busy = false; }
};
sendSelection();

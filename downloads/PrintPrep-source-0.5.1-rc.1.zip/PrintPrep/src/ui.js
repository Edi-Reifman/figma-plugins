'use strict';
const $ = id => document.getElementById(id);
let selection = null, locked = false, customProfile=null, genericProfile=null, pendingColour=null;
if(PUBLISH_CONFIG.sourceUrl){$('source-link').href=PUBLISH_CONFIG.sourceUrl;$('source-link').hidden=false;$('source-info').textContent='PrintPrep source code, build instructions and licences are available below.';}
if(PUBLISH_CONFIG.paypalUrl){
  try{
    const url=new URL(PUBLISH_CONFIG.paypalUrl);
    if(url.protocol==='https:'&&['paypal.me','paypal.com','www.paypal.com'].includes(url.hostname)&&!url.username&&!url.password){$('donation-link').href=url.href;$('donation').hidden=false;}
  }catch(_){}
}
const actionIds = ['create','attach','check','export'];
function post(msg) { parent.postMessage({pluginMessage:msg}, '*'); }
$('donation-link').onclick=e=>{e.preventDefault();post({type:'support-paypal'});};
$('source-link').onclick=e=>{e.preventDefault();post({type:'view-source'});};
function status(text, kind='info') { $('status').className = text ? 'notice '+kind : ''; $('status').textContent = text; }
function lock(value) { locked=value; for (const id of [...actionIds,'profile-mode','icc-file','choose-icc','render-intent','dpi-preset','dpi','format','withBleed','marks']) $(id).disabled=value; }
$('choose-icc').onclick=()=>$('icc-file').click();
function decodeBase64(value){const binary=atob(value),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes;}
function selectedProfile(){
  if($('profile-mode').value==='generic'){
    if(!genericProfile)genericProfile={bytes:PrintCore.validateCmykProfile(decodeBase64(GENERIC_CMYK_B64)).bytes,name:'Generic SWOP (Ghostscript)',filename:'PrintPrep-generic-SWOP.icc'};
    return genericProfile;
  }
  if(!customProfile)throw new Error('Upload your CMYK printer ICC profile before exporting, or explicitly select Generic SWOP for test output.');
  return customProfile;
}
function redrawProfile(){
  $('icc-file-label').hidden=$('profile-mode').value!=='custom';
  try{const p=selectedProfile();$('profile-status').textContent=$('profile-mode').value==='generic'
    ? "Generic SWOP is a fallback for test output, not a profile matched to your printer. Use your printer's ICC for production."
    : p.name+' · CMYK printer profile · loaded locally';
    $('profile-status').className='notice '+($('profile-mode').value==='generic'?'warning':'success');$('save-profile').hidden=false;
  }catch(e){$('profile-status').textContent=e.message;$('profile-status').className='notice';$('save-profile').hidden=true;}
}
$('profile-mode').onchange=()=>{redrawProfile();redraw();};
$('icc-file').onchange=async()=>{
  customProfile=null;redrawProfile();const file=$('icc-file').files[0];if(!file)return;
  try{if(file.size>32*1024*1024)throw new Error('ICC files must be 32 MB or smaller.');const profile=PrintCore.validateCmykProfile(new Uint8Array(await file.arrayBuffer()));
    customProfile={bytes:profile.bytes,name:file.name,filename:file.name};redrawProfile();status('CMYK output profile loaded.');
  }catch(e){redrawProfile();status(e.message,'error');}
};
$('save-profile').onclick=()=>{try{const p=selectedProfile();download(p.bytes,'application/vnd.iccprofile',p.filename);}catch(e){status(e.message,'error');}};
function tab(name) {
  for (const n of ['create','export']) { $('panel-'+n).classList.toggle('active',n===name); $('tab-'+n).classList.toggle('active',n===name); }
}
function form() { return PrintCore.settings(Object.fromEntries(['width','height','bleed','safe','dpi'].map(k=>[k,$(k).value]))); }
function redraw() {
  try { const d = PrintCore.dimensions(form()); $('create-summary').textContent=`Frame size including bleed: ${fmt(d.width)} × ${fmt(d.height)} mm.`; }
  catch(e) { $('create-summary').textContent=e.message; }
  const format=$('format').value;
  $('marks-label').hidden=format==='tiff';
  $('mode-note').textContent=format==='pdf-vector'
    ? 'Converted to CMYK through the selected ICC profile, retaining vectors where supported. DPI is an image-check threshold; it does not increase source image resolution.'
    : format==='eps'
    ? 'Converted to CMYK through the selected ICC profile. Vectors are retained where EPS supports them; transparency and complex effects may be rasterized at the selected DPI.'
    : 'CMYK TIFF: 4 channels, 8 bits per channel, uncompressed, with the selected ICC embedded. DPI sets pixel dimensions and is stored in the file. No alpha channel.';
  if (!selection || !selection.config) return;
  const s = selection.config;
  $('size').replaceChildren(document.createTextNode(`${fmt(s.width)} × ${fmt(s.height)} `));
  const unit = document.createElement('span'); unit.textContent='mm'; $('size').append(unit);
  $('export-summary').textContent=`Bleed: ${fmt(s.bleed)} mm per side · safe margin: ${fmt(s.safe)} mm`;
  $('selected-name').textContent=selection.name;
  try {
    const d = PrintCore.dimensions({...s,dpi:$('dpi').value},$('withBleed').checked);
    $('pixel-summary').textContent=format==='tiff'
      ? `${fmt(d.width)} × ${fmt(d.height)} mm · ${d.pxWidth} × ${d.pxHeight} px · about ${Math.ceil(d.pxWidth*d.pxHeight*4/1048576)} MB. Dimensions are rounded to whole pixels.`
      : `Artwork area: ${fmt(d.width)} × ${fmt(d.height)} mm${$('marks').checked ? ' + space for crop marks' : ''}.`;
  } catch(e) { $('pixel-summary').textContent=e.message; }
}
function fmt(n) { return Number(n.toFixed(3)).toLocaleString('en-GB'); }
function begin(message) { if (locked) return false; lock(true); status(message); return true; }
function request(type) {
  if (locked) return;
  try {
    let msg;
    if (type==='create' || type==='attach') msg={type,settings:form(),name:$('name').value};
    else {
      if (!selection || !selection.config) throw new Error('Select a PrintPrep layout.');
      const s = PrintCore.settings({...selection.config,dpi:$('dpi').value});
      if(type==='export'&&$('format').value==='tiff')PrintCore.rasterLimit(PrintCore.dimensions(s,$('withBleed').checked));
      if(type==='export'){const p=selectedProfile();pendingColour={...p,bytes:new Uint8Array(p.bytes),intent:Number($('render-intent').value)};}
      msg={type,dpi:s.dpi,format:$('format').value,withBleed:$('withBleed').checked,marks:$('marks').checked};
      $('report').replaceChildren();
    }
    begin(type==='export' ? 'Preparing your file…' : type==='check' ? 'Checking your layout…' : 'Preparing your layout…'); post(msg);
  } catch(e) { lock(false); status(e.message,'error'); }
}
for (const name of ['create','export']) $('tab-'+name).onclick=()=>tab(name);
for (const type of actionIds) $(type).onclick=()=>request(type);
$('preset').onchange=()=>{ if ($('preset').value!=='custom') { const [w,h]=$('preset').value.split(','); $('width').value=w; $('height').value=h; } redraw(); };
$('dpi-preset').onchange=()=>{
  const custom=$('dpi-preset').value==='custom';$('dpi-custom-label').hidden=!custom;
  if(!custom)$('dpi').value=$('dpi-preset').value;redraw();
};
function syncDpi(value){
  $('dpi').value=value;
  const known=['72','150','300','600','1200'].includes(String(value));
  $('dpi-preset').value=known?String(value):'custom';$('dpi-custom-label').hidden=known;
}
for (const id of ['width','height','bleed','safe','dpi','withBleed','marks','format']) $(id).addEventListener('input',()=>{ if(id==='width'||id==='height') $('preset').value='custom'; redraw(); });
function download(bytes,mime,name) {
  const url=URL.createObjectURL(new Blob([bytes],{type:mime})),a=document.createElement('a');
  a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
async function convertCmyk(pdf,format,d,colour,dpi){
  const url=URL.createObjectURL(new Blob([EPS_WORKER_SOURCE],{type:'application/javascript'}));
  let worker;
  try{
    worker=new Worker(url);
    const icc=new Uint8Array(colour.bytes),rgb=decodeBase64(SOURCE_SRGB_B64);
    return await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(new Error('CMYK conversion exceeded two minutes. Simplify effects or lower the DPI for raster output.')),120000);
      worker.onmessage=e=>{clearTimeout(timer);e.data.error?reject(new Error(e.data.error)):resolve(new Uint8Array(e.data.bytes));};
      worker.onerror=e=>{clearTimeout(timer);reject(new Error('CMYK converter error. Check the profile or simplify the layout.'));};
      worker.postMessage({pdf,packedWasm:EPS_WASM_PACKED,wasmInfo:EPS_WASM_INFO,dpi,format,width:d.pxWidth,height:d.pxHeight,icc,rgb,intent:colour.intent},[pdf.buffer,icc.buffer,rgb.buffer]);
    });
  }finally{if(worker)worker.terminate();URL.revokeObjectURL(url);}
}
window.onmessage=async event=>{
  const msg=event.data.pluginMessage;if(!msg)return;
  if(msg.type==='selection'){
    selection=msg.node;$('empty').hidden=!!(selection&&selection.config);$('export-body').hidden=!$('empty').hidden;
    if(selection&&selection.config){syncDpi(selection.config.dpi);}
    redraw();return;
  }
  if(msg.type==='error'){pendingColour=null;lock(false);status(msg.message,'error');return;}
  if(msg.type==='created'||msg.type==='attached'){lock(false);status(msg.type==='created'?'Layout created. Add your design inside the frame.':'Settings attached to the frame.','success');tab('export');return;}
  if(msg.type==='report'){
    $('report').replaceChildren();
    const n=msg.report.warnings.filter(w=>w.level==='warning').length;
    const lead=document.createElement('div');lead.className='notice '+(n?'warning':'success');
    lead.textContent=`Images checked: ${msg.report.checked}. ${n?'Warnings: '+n+'.':'No issues found in the checks performed.'}`;
    $('report').append(lead);
    for(const w of msg.report.warnings){const el=document.createElement('div');el.className='notice '+(w.level==='warning'?'warning':'');el.textContent=w.text;$('report').append(el);}
    return;
  }
  if(msg.type==='checked'){lock(false);status('Check complete. Review the results below.','success');return;}
  if(msg.type==='exported'){
    try{
      status('Building your file and setting its dimensions…');
      if(!['pdf-vector','eps','tiff'].includes(msg.format)) throw new Error('Choose PDF, EPS or TIFF.');
      const s=PrintCore.settings(msg.settings);
      const d=PrintCore.dimensions(s,msg.withBleed);
      const colour=pendingColour||{...selectedProfile(),intent:Number($('render-intent').value)};
      if(msg.format==='tiff')PrintCore.rasterLimit(d);
      const pdf=await PrintCore.makePdf(PDFLib,new Uint8Array(msg.bytes),'vector',s,msg.withBleed,msg.format!=='tiff'&&msg.marks);
      status('Converting to CMYK with '+colour.name+'…');
      let bytes=await convertCmyk(pdf,msg.format,d,colour,s.dpi),ext,mime;
      if(msg.format==='tiff'){
        bytes=PrintCore.finalizeCmykTiff(bytes,colour.bytes,s.dpi,d.pxWidth,d.pxHeight);ext='tif';mime='image/tiff';
      }else if(msg.format==='eps'){
        bytes=PrintCore.epsBounds(bytes,s,msg.withBleed,msg.marks);ext='eps';mime='application/postscript';
      }else{
        bytes=await PrintCore.finalizeCmykPdf(PDFLib,bytes,s,msg.withBleed,msg.marks,colour.bytes,colour.name);ext='pdf';mime='application/pdf';
      }
      const safeName=msg.name.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').slice(0,100);
      download(bytes,mime,`${safeName}_${s.width}x${s.height}mm_CMYK_${msg.format==='pdf-vector'?'vector':s.dpi+'dpi'}${msg.withBleed?'_bleed'+s.bleed+'mm':''}.${ext}`);
      status('Your file is ready and the download has started. Review any warnings below.','success');
    }catch(e){status('Export failed: '+e.message,'error');}
    finally{pendingColour=null;lock(false);}
  }
};
redrawProfile();redraw();post({type:'ready'});
